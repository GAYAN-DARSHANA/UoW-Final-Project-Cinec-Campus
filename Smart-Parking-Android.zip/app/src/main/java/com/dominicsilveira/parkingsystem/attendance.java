package com.dominicsilveira.parkingsystem;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.DownloadListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class attendance extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);
       /* webView = findViewById(R.id.webView);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://vlavasmartparking.000webhostapp.com");
*/
        webView = new WebView(this);

        webView.getSettings().setJavaScriptEnabled(true); // enable javascript

        final Activity activity = this;

        webView.setWebViewClient(new WebViewClient() {
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(activity, description, Toast.LENGTH_SHORT).show();
            }
        });
        //-------------Downloading Enable Functioning on Web View---------------------------------
        webView.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimetype,
                                        long contentLength) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse("https://vlavasmartparking.000webhostapp.com"));
                startActivity(i);
            }
        });
        //---------------------------------------------------------------
        webView.loadUrl("https://vlavasmartparking.000webhostapp.com");
        setContentView(webView);


        }
@Override
    public void onBackPressed(){
        if(webView.canGoBack()){
            webView.goBack();
        }
        super.onBackPressed();
}
}