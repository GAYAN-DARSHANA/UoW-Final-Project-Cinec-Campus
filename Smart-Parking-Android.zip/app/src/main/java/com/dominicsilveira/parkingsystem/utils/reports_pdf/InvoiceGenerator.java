package com.dominicsilveira.parkingsystem.utils.reports_pdf;

import android.annotation.SuppressLint;
import android.app.Application;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.dominicsilveira.parkingsystem.classes.BookedSlots;
import com.dominicsilveira.parkingsystem.classes.ParkingArea;
import com.dominicsilveira.parkingsystem.classes.User;
import com.dominicsilveira.parkingsystem.utils.BasicUtils;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;

public class InvoiceGenerator {
    BookedSlots bookingSlot;
    ParkingArea parkingArea;
    String bookingKey;
    User userObj;
    File file;
   // public InvoiceGenerator(){}

    public InvoiceGenerator(BookedSlots bookingSlot,ParkingArea parkingArea,String key,User userObj,File file){
        this.bookingSlot=bookingSlot;
        this.parkingArea=parkingArea;
        this.bookingKey=key;
        this.userObj=userObj;
        this.file=file;
    }

    public InvoiceGenerator() {

    }


    public void create(){
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormatter = new SimpleDateFormat("dd MMM, yyyy");
        @SuppressLint("SimpleDateFormat") SimpleDateFormat timeFormatter = new SimpleDateFormat("hh:mm a");
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateTimeFormatter = new SimpleDateFormat("dd-MMM-yyyy, hh:mm a");

        PdfDocument pdfDocument=new PdfDocument();
        Paint mypaint=new Paint();
        PdfDocument.PageInfo pageInfo=new PdfDocument.PageInfo.Builder(850,700,1).create();
        PdfDocument.Page page=pdfDocument.startPage(pageInfo);
        Canvas canvas=page.getCanvas();

        mypaint.setTextSize(40);
        canvas.drawText("Vlava Smart Parking System",30,60,mypaint);

        mypaint.setTextSize(25);
        canvas.drawText(parkingArea.name,30,90,mypaint);

        mypaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("Invoice no",canvas.getWidth()-40,40,mypaint);
        canvas.drawText(bookingKey,canvas.getWidth()-40,80,mypaint);

        mypaint.setTextAlign(Paint.Align.LEFT);
        mypaint.setColor(Color.rgb(150,150,150));
        canvas.drawRect(30,120,canvas.getWidth()-30,130,mypaint);

        mypaint.setColor(Color.BLACK);
        canvas.drawText("Date: ",50,170,mypaint);
        canvas.drawText(dateFormatter.format(bookingSlot.startTime),250,170,mypaint);
        canvas.drawText("Time: ",620,170,mypaint);
        mypaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(timeFormatter.format(bookingSlot.startTime),canvas.getWidth()-50,170,mypaint);

        mypaint.setTextAlign(Paint.Align.LEFT);
        mypaint.setColor(Color.rgb(150,150,150));
        canvas.drawRect(30,220,canvas.getWidth()-30,270,mypaint);

        mypaint.setColor(Color.WHITE);
        canvas.drawText("Bill To: ",50,255,mypaint);
        canvas.drawText("User ID: ",450,255,mypaint);
        mypaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(bookingSlot.userID,canvas.getWidth()-50,255,mypaint);

        mypaint.setColor(Color.BLACK);
        mypaint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("Customer Name: ",50,320,mypaint);
        canvas.drawText(userObj.name,250,320,mypaint);
        canvas.drawText("Phone No: ",620,320,mypaint);
        mypaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(userObj.contact_no,canvas.getWidth()-50,320,mypaint);

        mypaint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("Email ID: ",50,365,mypaint);
        canvas.drawText(userObj.email,250,365,mypaint);
        canvas.drawText("Slot No: ",620,365,mypaint);
        mypaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(bookingSlot.slotNo,canvas.getWidth()-50,365,mypaint);

        mypaint.setTextAlign(Paint.Align.LEFT);
        mypaint.setColor(Color.rgb(150,150,150));
        canvas.drawRect(30,415,canvas.getWidth()-30,465,mypaint);

        mypaint.setColor(Color.WHITE);
        canvas.drawText("Plate-Number",50,450,mypaint);
        canvas.drawText("Wheeler-Type",240,450,mypaint);
        mypaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("Start-Time",canvas.getWidth()-320,450,mypaint);
        canvas.drawText("End-Time",canvas.getWidth()-50,450,mypaint);

        mypaint.setTextAlign(Paint.Align.LEFT);
        mypaint.setColor(Color.BLACK);
        canvas.drawText(bookingSlot.numberPlate,50,495,mypaint);
        canvas.drawText(String.valueOf(bookingSlot.wheelerType),240,495,mypaint);
        mypaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(dateTimeFormatter.format(bookingSlot.startTime),canvas.getWidth()-320,495,mypaint);
        canvas.drawText(dateTimeFormatter.format(bookingSlot.endTime),canvas.getWidth()-50,495,mypaint);
        mypaint.setTextAlign(Paint.Align.LEFT);

        mypaint.setColor(Color.rgb(150,150,150));
        canvas.drawRect(30,565,canvas.getWidth()-40,575,mypaint);

        mypaint.setColor(Color.BLACK);
        mypaint.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));

        mypaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("Total Cost (Rs.):- "+String.valueOf(bookingSlot.amount),canvas.getWidth()-50,615,mypaint);
        String paid=(bookingSlot.hasPaid==1)?"YES":"NO";
        canvas.drawText("Paid:- "+paid,canvas.getWidth()-50,660,mypaint);

        pdfDocument.finishPage(page);
        String targetPdf = "/Download/Invoice.pdf";
        File filePath;
        filePath = new File(targetPdf);
        //filePath = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), targetPdf.toString());
        try {
            pdfDocument.writeTo(new FileOutputStream(filePath));          // pdfDocument.writeTo(new "file://" + separator.getOutputStream(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
        pdfDocument.close();

    }

    //---------------
    // create a new document
    //PdfDocument document = new PdfDocument();

    // crate a page description
    //PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();

    // start a page
  //  PdfRenderer.Page page = document.startPage(pageInfo);

   // Canvas canvas=page.getCanvas());
    // draw something on the page
  //  Paint paint = new Paint();
   // paint.setColor(Color.RED);

   // canvas.drawCircle(50, 50, 30, paint);

    // finish the page
   // document.finishPage(page);

    // write the document content
    //document.writeTo(getOutputStream());

    // close the document
    // document.close();
    //---------------

    BasicUtils utils=new BasicUtils();


    //this method will upload the file
    public void uploadFile(final Context context,Application application) {
        if(utils.isNetworkAvailable(application)) {
            //if there is a file to upload
            Uri filePath = Uri.fromFile(file);

            if (filePath != null) {
                //displaying a progress dialog while upload is going on
                final ProgressDialog progressDialog = new ProgressDialog(context);
                progressDialog.setTitle("Uploading");
                progressDialog.show();

                FirebaseStorage storage = FirebaseStorage.getInstance();

                StorageReference invoiceRef = storage.getReference().child("invoice/".concat(bookingSlot.userID).concat("/").concat(bookingKey).concat(".pdf"));
                invoiceRef.putFile(filePath)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                //if the upload is successfull
                                //hiding the progress dialog
                                try {
                                    progressDialog.dismiss();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                //and displaying a success toast
                                Toast.makeText(context, "File Uploaded ", Toast.LENGTH_LONG).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                //if the upload is not successfull
                                //hiding the progress dialog
                                try {
                                    progressDialog.dismiss();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                                //and displaying error message
                                Toast.makeText(context, exception.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                //calculating progress percentage
                                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();

                                //displaying percentage in progress dialog
                                progressDialog.setMessage("Uploaded " + ((int) progress) + "%...");
                            }
                        });
            }
            //if there is not any file
            else {
                //you can display an error toast
                Toast.makeText(context, "No file Available!", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(context, "No Network Available!", Toast.LENGTH_SHORT).show();
        }
    }

    public void downloadFile(String userID, String bookingKey, Context context, Application application) {
        if(utils.isNetworkAvailable(application)){
            FirebaseStorage storage = FirebaseStorage.getInstance();
            StorageReference invoiceRef = storage.getReference().child("invoice/".concat(userID).concat("/").concat(bookingKey).concat(".pdf"));

            final File localFile = new File(context.getExternalCacheDir(),File.separator + "invoice.pdf");
           //Uri localFile = FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".provider").toString();
            invoiceRef.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                    Log.e("firebase ",";local tem file created  created " +localFile.toString());
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    Log.e("firebase ",";local tem file not created  created " +exception.toString());
                }
            });
        }else{
            Toast.makeText(context, "No Network Available!", Toast.LENGTH_SHORT).show();
        }


    }

    public void openFile(Context context) {



        final File localFile = new File(context.getExternalCacheDir(), File.separator + "invoice.pdf");
        Intent target = new Intent(Intent.ACTION_VIEW);
        target.setDataAndType(Uri.fromFile(localFile),"application/pdf");
        target.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        Intent intent = Intent.createChooser(target, "Open File");
        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            // Instruct the user to install a PDF reader here, or something
        }
    }

 public void shareFile(Context context) {
        final File localFile = new File(context.getExternalCacheDir(), File.separator + "invoice.pdf");
        Intent share = new Intent(Intent.ACTION_SEND);
        if(localFile.exists()) {
            share.setType("application/pdf");
            share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(localFile));
            share.putExtra(Intent.EXTRA_SUBJECT, "Sharing File...");
            share.putExtra(Intent.EXTRA_TEXT, "Sharing File...");
            context.startActivity(Intent.createChooser(share, "Share File"));
        }
    }
}
