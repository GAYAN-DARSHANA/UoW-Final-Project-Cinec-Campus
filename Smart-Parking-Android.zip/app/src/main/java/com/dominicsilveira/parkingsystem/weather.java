package com.dominicsilveira.parkingsystem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class weather extends AppCompatActivity {
    // creating variables for our list view.

    private TextView tem,hum,des;
    private FirebaseDatabase mDatabase;
    private Button ref;

    // creating a variable for database reference.
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        tem = (TextView) findViewById(R.id.temp);
        hum = (TextView) findViewById(R.id.humi);

        ref = (Button) findViewById(R.id.ref);




        ref.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                reference = FirebaseDatabase.getInstance().getReference().child("whetherStatus");
                reference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String temp = dataSnapshot.child("temperature").getValue().toString();
                        String hump = dataSnapshot.child("humidity").getValue().toString();

                        tem.setText(temp + " 'c");
                        hum.setText(hump + " %");

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }




                });

            }
        });

    }


    }





