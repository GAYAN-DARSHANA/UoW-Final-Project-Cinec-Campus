package com.dominicsilveira.parkingsystem.classes;

import java.io.Serializable;
import java.util.Date;

    public class AttSlots implements Serializable {
        public String uid,device;
        public int status;
        public Date time;

        public AttSlots(){}

        public AttSlots(String uid, String device, int status, Date time){
            this.uid=uid;
            this.device=device;
            this.status=status;
            this.time=time;

        }

    }


