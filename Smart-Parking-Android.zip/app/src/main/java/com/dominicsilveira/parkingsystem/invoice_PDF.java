package com.dominicsilveira.parkingsystem;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.dominicsilveira.parkingsystem.classes.BookedSlots;
import com.dominicsilveira.parkingsystem.classes.ParkingArea;
import com.dominicsilveira.parkingsystem.classes.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;

public class invoice_PDF extends AppCompatActivity {
    // creating variables for our list view.

    BookedSlots bookingSlot;
    ParkingArea parkingArea;
    String bookingKey;
    User userObj;
    File file;
    TextView txtParea;

    private TextView txtPAreaName,txtInvoiceNo,txtBookDate,txtBookTime,txtUserID,txtUserName,txtParkedSlot,txtEndTime,txtCost;
    private FirebaseDatabase mDatabase;
    private Button btnInvoice;

    public invoice_PDF(BookedSlots bookingSlot, ParkingArea parkingArea, String key, User userObj, File file){
        this.bookingSlot=bookingSlot;
        this.parkingArea=parkingArea;
        this.bookingKey=key;
        this.userObj=userObj;
        this.file=file;
    }

    // creating a variable for database reference.
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoce02);


        txtPAreaName = (TextView) findViewById(R.id.txtPAreaName);
        txtInvoiceNo = (TextView) findViewById(R.id.txtInvoiceNo);
        txtBookDate = (TextView) findViewById(R.id.txtBookDate);
        txtBookTime = (TextView) findViewById(R.id.txtBookTime);
        txtUserID = (TextView) findViewById(R.id.txtUserID);
        txtUserName = (TextView) findViewById(R.id.txtUserName);
        txtParkedSlot = (TextView) findViewById(R.id.txtParkedSlot);
        txtEndTime = (TextView) findViewById(R.id.txtEndTime);
        txtCost = (TextView) findViewById(R.id.txtCost);

        btnInvoice = (Button) findViewById(R.id.btnInvoice);



        btnInvoice.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                reference = FirebaseDatabase.getInstance().getReference().child("SlotStatus").child("SLOTS");
                reference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        String Slot05 = dataSnapshot.child("Slot05").getValue().toString();
                        String Slot06 = dataSnapshot.child("Slot06").getValue().toString();
                        String Slot07 = dataSnapshot.child("Slot07").getValue().toString();
                        // txtSlot01.setText("Slot04");
                        txtBookDate.setText(Slot05);
                        txtBookTime.setText(Slot06);
                        txtCost.setText(Slot07);
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }


                });
            }
        });
    }
}

/*
package com.example.layoutpdf;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.function.BiFunction;

public class MainActivity2 extends AppCompatActivity {
ImageView avatarview;
TextView fnameview,lnameview,emailview,mobileview,ageview;
LinearLayout linearLayout;
ImageButton save;
Bitmap bitmap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        findId();
        viewData();
        savePdf();

    }

    private void savePdf() {
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("size",linearLayout.getWidth()+" "+linearLayout.getHeight());
              bitmap=loadBitmapFromView(linearLayout,linearLayout.getWidth(),linearLayout.getHeight());
              createPdf();
            }
        });
    }

    private void createPdf() {
        DisplayMetrics displayMetrics=new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        float height=displayMetrics.heightPixels;
        float width=displayMetrics.widthPixels;

        int convertHeight=(int)height,
                convertWidth=(int)width;

        PdfDocument document=new PdfDocument();
        PdfDocument.PageInfo pageInfo=new PdfDocument.PageInfo.Builder(convertWidth,convertHeight,1).create();
        PdfDocument.Page page=document.startPage(pageInfo);

        Canvas canvas=page.getCanvas();
        Paint paint=new Paint();
        canvas.drawPaint(paint);
        bitmap=Bitmap.createScaledBitmap(bitmap,convertWidth,convertHeight,true);
        canvas.drawBitmap(bitmap,0,0,null);
        document.finishPage(page);

        //write document content
        String targetPdf="sdcard/page.pdf";
        File filepath=new File(targetPdf);
        try {
            document.writeTo(new FileOutputStream(filepath));
        }catch (IOException e){
            e.printStackTrace();
            Toast.makeText(this, "something want wrong try again"+e.toString(), Toast.LENGTH_SHORT).show();
        }
        //close document
        document.close();
        Toast.makeText(this, "pdf created successfully", Toast.LENGTH_SHORT).show();
    openPdf();
    }

    private void openPdf() {
        File file=new File("/sdcard/page.pdf");
        Intent intent=new Intent(Intent.ACTION_VIEW);
        Uri uri=Uri.fromFile(file);
        intent.setDataAndType(uri,"application/pdf");
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try {
            startActivity(intent);
        }catch (ActivityNotFoundException e){
            Toast.makeText(this, "No application found for pdf reader", Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap loadBitmapFromView(LinearLayout linearLayout, int width, int height) {
    bitmap=Bitmap.createBitmap(width,height, Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(bitmap);
        linearLayout.draw(canvas);
        return bitmap;
    }

    private void viewData() {
        Intent intent=getIntent();
        byte[]bytes=intent.getByteArrayExtra("avatar");
        Bitmap bitmap= BitmapFactory.decodeByteArray(bytes,0,bytes.length);
        avatarview.setImageBitmap(bitmap);
        String fname=intent.getStringExtra("fname");
        String lname=intent.getStringExtra("lname");
        String email=intent.getStringExtra("email");
        String mobile=intent.getStringExtra("mobile");
        String age=intent.getStringExtra("age");

        //set view
        fnameview.setText(":-"+fname.toString());
        lnameview.setText(":-"+lname.toString());
        emailview.setText(":-"+email.toString());
        mobileview.setText(":-"+mobile.toString());
        ageview.setText(":-"+age.toString());
    }

    private void findId() {
        avatarview=(ImageView)findViewById(R.id.avatarview);
        fnameview=(TextView)findViewById(R.id.fnameview);
        lnameview=(TextView)findViewById(R.id.lnameview);
        emailview=(TextView)findViewById(R.id.emailview);
        mobileview=(TextView)findViewById(R.id.mobileview);
        ageview=(TextView)findViewById(R.id.ageview);
        linearLayout=findViewById(R.id.lld);
        save=findViewById(R.id.save);
    }
}
}*/
