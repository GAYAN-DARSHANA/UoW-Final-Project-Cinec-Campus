package com.dominicsilveira.parkingsystem;


import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.dominicsilveira.parkingsystem.classes.BookedSlots;
import com.dominicsilveira.parkingsystem.classes.User;
import com.dominicsilveira.parkingsystem.utils.AppConstants;
import com.dominicsilveira.parkingsystem.utils.BasicUtils;
import com.dominicsilveira.parkingsystem.utils.notifications.NotificationHelper;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;

public class PDFActivity extends AppCompatActivity {

    TextView txtPAreaName,txtInvoiceNo,txtBookDate,txtBookTime,txtUserID,txtUserName,txtParkedSlot,txtEndTime,txtCost;

    Button btn,btnScroll;
    public String userID;
    //private Button btn, btnScroll;
    private LinearLayout llPdf;
    private Bitmap bitmap;

    BookedSlots bookingSlot;

    User userObj;
    NotificationHelper mNotificationHelper;
    AppConstants globalClass;
    BasicUtils utils=new BasicUtils();

    FirebaseAuth auth;
    FirebaseDatabase db;

    String UUID;
    Boolean run_once=false;

    private void initComponents() {
        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();

        Bundle bundle = getIntent().getExtras();
        UUID=bundle.getString("UUID");
//        bookingSlot = (BookedSlots) getIntent().getSerializableExtra("BookedSlot");

        getSupportActionBar().setTitle(UUID);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        globalClass=(AppConstants)getApplicationContext();
        userObj=globalClass.getUserObj();

        txtPAreaName = findViewById(R.id.txtPAreaName);
        txtInvoiceNo = findViewById(R.id.txtInvoiceNo);
        txtBookDate = findViewById(R.id.txtBookDate);
        txtBookTime = findViewById(R.id.txtBookTime);
        txtUserName = findViewById(R.id.txtUserName);
        txtParkedSlot = findViewById(R.id.txtParkedSlot);
        txtEndTime = findViewById(R.id.txtEndTime);
        txtCost = findViewById(R.id.txtCost);
        btn = findViewById(R.id.btn);
        btnScroll = findViewById(R.id.btnScroll);
        txtUserID= findViewById(R.id.txtUserID);
        mNotificationHelper=new NotificationHelper(this);
        llPdf = findViewById(R.id.llPdf);
    }
    private void attachListeners() {
        db.getReference().child("BookedSlots").child(UUID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                bookingSlot=snapshot.getValue(BookedSlots.class);
                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("hh:mm a");
                txtBookTime.setText(simpleDateFormat.format(bookingSlot.startTime));
                txtEndTime.setText(simpleDateFormat.format(bookingSlot.endTime));
           //     checkoutTimeText.setText(simpleDateFormat.format(bookingSlot.checkoutTime));
                simpleDateFormat=new SimpleDateFormat("dd-MM-yyyy");
                txtBookDate.setText(simpleDateFormat.format(bookingSlot.startTime));
           //     endDateText.setText(simpleDateFormat.format(bookingSlot.endTime));
           //     checkoutDateText.setText(simpleDateFormat.format(bookingSlot.checkoutTime));
                txtUserName.setText(bookingSlot.numberPlate);
           //     wheelerText.setText(String.valueOf(bookingSlot.wheelerType));
                if(bookingSlot.hasPaid==0){
                    txtCost.setText("Rs. "+String.valueOf(bookingSlot.amount).concat("  (Not Paid)"));
                }else{
                    txtCost.setText("Rs. "+ String.valueOf(bookingSlot.amount).concat("  (Paid)"));
                }

        /*       updatePayCheckoutUI();

                findViewById(R.id.openInvoicePdf).setOnClickListener(BookingDetailsActivity.this);
                findViewById(R.id.shareInvoicePdf).setOnClickListener(BookingDetailsActivity.this);

                if(!run_once){
                    run_once=true;
                    attachParkingListeners();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });*/

        db.getReference().child("BookedSlots").child(UUID).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {}
            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                if(snapshot.getKey().equals("hasPaid")){
                    try{
                        bookingSlot.hasPaid=snapshot.getValue(int.class);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                    Log.e(String.valueOf(PDFActivity.this.getClass()),"Fetched updated BookedSlots:"+  String.valueOf(snapshot.getKey())+snapshot.getValue(int.class));
                }
            }
            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {}
            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {}
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });

/*

    }


    private void attachParkingListeners(){
        db.getReference().child("ParkingAreas").child(bookingSlot.placeID)
                .addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {}
                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        if(snapshot.getKey().equals("availableSlots") || snapshot.getKey().equals("occupiedSlots") || snapshot.getKey().equals("totalSlots")){
                            try{
                                parkingArea.setData(snapshot.getKey(),snapshot.getValue(int.class));
                                updatePayCheckoutUI();
                            }catch(Exception e){
                                e.printStackTrace();
                            }
                            Log.e(String.valueOf(BookingDetailsActivity.this.getClass()),"Fetched updated parking Area:"+  String.valueOf(snapshot.getKey())+snapshot.getValue(int.class));
                        }
                    }
                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {}
                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {}
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });

        db.getReference().child("ParkingAreas").child(bookingSlot.placeID)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        ParkingArea parkingArea = snapshot.getValue(ParkingArea.class);
                        setAddValues(parkingArea);
                        Log.e(String.valueOf(BookingDetailsActivity.this.getClass()),"Fetched parking Area:"+ String.valueOf(snapshot.getKey()));
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });*/

    }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pdf_activity);
        initComponents();
        attachListeners();
        btnScroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PDFActivity.this,ScrollActivity.class);
                startActivity(intent);

            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("size"," "+llPdf.getWidth() +"  "+llPdf.getWidth());
                bitmap = loadBitmapFromView(llPdf, llPdf.getWidth(), llPdf.getHeight());
                createPdf();
            }
        });

    }

    public static Bitmap loadBitmapFromView(View v, int width, int height) {
        Bitmap b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        v.draw(c);

        return b;
    }

    private void createPdf(){
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        //  Display display = wm.getDefaultDisplay();
        DisplayMetrics displaymetrics = new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        float hight = displaymetrics.heightPixels ;
        float width = displaymetrics.widthPixels ;

        int convertHighet = (int) hight, convertWidth = (int) width;

//        Resources mResources = getResources();
//        Bitmap bitmap = BitmapFactory.decodeResource(mResources, R.drawable.screenshot);

        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(convertWidth, convertHighet, 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);

        Canvas canvas = page.getCanvas();

        Paint paint = new Paint();
        canvas.drawPaint(paint);

        bitmap = Bitmap.createScaledBitmap(bitmap, convertWidth, convertHighet, true);

        paint.setColor(Color.BLUE);
        canvas.drawBitmap(bitmap, 0, 0 , null);
        document.finishPage(page);

        // write the document content
        String targetPdf = "/storage/emulated/0/Download/TestPDF.pdf";
        File filePath;
        filePath = new File(targetPdf);
        try {
            document.writeTo(new FileOutputStream(filePath));

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, String.format("Something wrong: %s", e.toString()), Toast.LENGTH_LONG).show();
        }

        // close the document
        document.close();
        Toast.makeText(this, "PDF is created!!!", Toast.LENGTH_SHORT).show();

        openGeneratedPDF();

    }

    private void openGeneratedPDF(){
        File file = new File("/storage/emulated/0/Download/TestPDF.pdf");
        if (file.exists())
        {
            Intent intent=new Intent(Intent.ACTION_VIEW);
            Uri uri = Uri.fromFile(file);
            intent.setDataAndType(uri, "application/pdf");
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            try
            {
                startActivity(intent);
            }
            catch(ActivityNotFoundException e)
            {
                Toast.makeText(PDFActivity.this, "No Application available to view pdf", Toast.LENGTH_LONG).show();
            }
        }
    }

}
