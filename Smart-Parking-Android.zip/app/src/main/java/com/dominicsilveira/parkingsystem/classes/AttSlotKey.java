package com.dominicsilveira.parkingsystem.classes;

import java.util.List;

public class AttSlotKey {
    public static String key;
    public AttSlots attSlots;
 //   public String key;

    public AttSlotKey(){}
    public AttSlotKey(AttSlots AttSlots, String key){
        this.attSlots=AttSlots;
        this.key=key;
    }

    public static void add(List<AttSlotKey> attSlotKeyList) {
    }
}