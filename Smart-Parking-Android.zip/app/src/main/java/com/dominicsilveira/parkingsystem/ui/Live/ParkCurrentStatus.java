package com.dominicsilveira.parkingsystem.ui.Live;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.dominicsilveira.parkingsystem.PDFActivity;
import com.dominicsilveira.parkingsystem.R;
import com.dominicsilveira.parkingsystem.classes.BookedSlots;
import com.dominicsilveira.parkingsystem.classes.ParkingArea;
import com.dominicsilveira.parkingsystem.classes.SlotNoInfo;
import com.dominicsilveira.parkingsystem.utils.BasicUtils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;


public class ParkCurrentStatus extends Fragment  {

    TextView txtSlot01,txtSlot02,txtSlot03,txtSlot04,availableText,occupiedText,slotName,numberPlate;
    LinearLayout expandCard,slotStatus,slot_individual_list_view;
    Button btnrep;
    SlotNoInfo slotNoInfo;


    private FirebaseDatabase mDatabase;
    FirebaseAuth auth;
    FirebaseDatabase db;
    Calendar calendar;
    BasicUtils utils=new BasicUtils();

    BookedSlots bookingSlot=new BookedSlots();




    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.activity_park_current_status, container, false);

        initComponents(root);
        attachListeners();

        if(!utils.isNetworkAvailable(getActivity().getApplication())){
            Toast.makeText(getActivity(), "No Network Available!", Toast.LENGTH_SHORT).show();
        }


        return root;
    }

    @SuppressLint("SimpleDateFormat")
    private void initComponents(View root) {
        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();

        btnrep=root.findViewById(R.id.btnrep);

        txtSlot01 = root.findViewById(R.id.txtSlot01);
        txtSlot02 = root.findViewById(R.id.txtSlot02);
        txtSlot03 = root.findViewById(R.id.txtSlot03);
        txtSlot04 = root.findViewById(R.id.txtSlot04);
        availableText = root.findViewById(R.id.availableText);
        occupiedText = root.findViewById(R.id.occupiedText);




    }

    private void attachListeners() {
        // creating a variable for database reference.
        final DatabaseReference[] reference = new DatabaseReference[1];

        btnrep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view1) {
                startActivity(new Intent(getActivity(), PDFActivity.class));
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });
        db.getReference().child("SlotStatus").orderByChild("SLOTS").addListenerForSingleValueEvent(new ValueEventListener() {
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {


                    String Slot01 = dataSnapshot.child("Slot01").getValue().toString();
                    String Slot02 = dataSnapshot.child("Slot02").getValue().toString();
                    String Slot03 = dataSnapshot.child("Slot03").getValue().toString();
                    String Slot04 = dataSnapshot.child("Slot04").getValue().toString();
                    txtSlot01.setText("   -  " + Slot01);
                    txtSlot02.setText("   -  " + Slot02);
                    txtSlot03.setText("   -  " + Slot03);
                    txtSlot04.setText("   -  " + Slot04);
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        db.getReference().child("ParkingAreas").orderByChild("userID").equalTo(auth.getCurrentUser().getUid())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot ) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            ParkingArea parkingArea = dataSnapshot.getValue(ParkingArea.class);

                            Log.e("DashboardOwnerFragment", "Fetch parking area");
                            availableText.setText(String.valueOf("   -  " + parkingArea.availableSlots + "   slots"));
                            occupiedText.setText(String.valueOf("   -  " + parkingArea.occupiedSlots + "   slots"));


                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });





        }

}





/*
public class ParkCurrentStatus extends AppCompatActivity {
    // creating variables for our list view.

    private TextView txtSlot01,txtSlot02,txtSlot03,txtSlot04;
    private FirebaseDatabase mDatabase;
    private Button ref;

    // creating a variable for database reference.
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_park_current_status);

         txtSlot01 = (TextView) findViewById(R.id.txtSlot01);
         txtSlot02 = (TextView) findViewById(R.id.txtSlot02);
         txtSlot03 = (TextView) findViewById(R.id.txtSlot03);
         txtSlot04 = (TextView) findViewById(R.id.txtSlot04);
         ref = (Button) findViewById(R.id.refresh);




        ref.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                reference = FirebaseDatabase.getInstance().getReference().child("SlotStatus").child("SLOTS");
                reference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String Slot01 = dataSnapshot.child("Slot01").getValue().toString();
                        String Slot02 = dataSnapshot.child("Slot02").getValue().toString();
                        String Slot03 = dataSnapshot.child("Slot03").getValue().toString();
                        String Slot04 = dataSnapshot.child("Slot04").getValue().toString();
                        txtSlot01.setText(Slot01);
                        txtSlot02.setText(Slot02);
                        txtSlot03.setText(Slot03);
                        txtSlot04.setText(Slot04);
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }


                });

            }
        });

    }
}

 */
