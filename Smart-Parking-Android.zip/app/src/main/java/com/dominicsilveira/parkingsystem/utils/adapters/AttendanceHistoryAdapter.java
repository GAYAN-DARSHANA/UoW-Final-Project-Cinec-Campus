package com.dominicsilveira.parkingsystem.utils.adapters;


import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.dominicsilveira.parkingsystem.R;
import com.dominicsilveira.parkingsystem.classes.AttSlotKey;
import com.dominicsilveira.parkingsystem.classes.AttSlots;
import com.dominicsilveira.parkingsystem.common.BookingDetailsActivity;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class AttendanceHistoryAdapter extends RecyclerView.Adapter<AttendanceHistoryAdapter.MyViewHolder>{
    Activity context;
    List<AttSlotKey> attSlotKeyList = new ArrayList<AttSlotKey>();
    FirebaseAuth auth;
    FirebaseDatabase db;

    public AttendanceHistoryAdapter(List<AttSlotKey> attSlotKeyList){
        this.attSlotKeyList = attSlotKeyList;
       // Log.d("distParkingArea", String.valueOf(attSlotKeyList));
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        MaterialCardView userHistoryCard;
        TextView uid,time,status,device;

        MyViewHolder(View itemView) {
            super(itemView);
            userHistoryCard = (MaterialCardView)itemView.findViewById(R.id.userHistoryCard);
            uid = (TextView)itemView.findViewById(R.id.attID);
            time = (TextView)itemView.findViewById(R.id.time);
            status = (TextView)itemView.findViewById(R.id.status);
            device = (TextView)itemView.findViewById(R.id.checkinout);
        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        context = (Activity) recyclerView.getContext();
    }

    // Create new views (invoked by the layout manager)
    @Override
    public AttendanceHistoryAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                                    int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.include_history_row_layout, parent, false);
        AttendanceHistoryAdapter.MyViewHolder pvh = new AttendanceHistoryAdapter.MyViewHolder(v);
        return pvh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(final AttendanceHistoryAdapter.MyViewHolder holder, int position) {
        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();
        AttSlotKey attSlotKey=attSlotKeyList.get(position);
//        final String id = (String) closestDistance.key;
//        final ParkingArea parkingArea = (ParkingArea) closestDistance.parkingArea;
        setDatas(holder,attSlotKey);
    }

    public void setDatas(MyViewHolder holder, final AttSlotKey bookedSlotKey){
        final AttSlots attSlots= bookedSlotKey.attSlots;
        holder.uid.setText(attSlots.uid);
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd-MM-yyyy HH:mm a");
        holder.time.setText(simpleDateFormat.format(attSlots.time));
        //holder.endDate.setText(simpleDateFormat.format(attSlots.checkoutTime));
       // String hasPaid="Paid: ".concat((attSlots.hasPaid==1)?"Yes":"No");
       // holder.hasPaid.setText(hasPaid);
        holder.userHistoryCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context, BookingDetailsActivity.class);
                intent.putExtra("UUID", AttSlotKey.key);
                intent.putExtra("AttSlots", attSlots);
                context.startActivity(intent);
                context.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return attSlotKeyList.size();
    }
}
